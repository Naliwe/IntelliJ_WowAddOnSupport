<?xml version='1.0' encoding='ISO-8859-1' ?>
<!DOCTYPE helpset
  PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN"
         "http://java.sun.com/products/javahelp/helpset_2_0.dtd">

<helpset version="2.0">

  <!-- title -->
  <title>Lua Manual</title>

  <!-- maps -->
  <maps>
     <homeID>main</homeID>
     <mapref location="Map.jhm"/>
  </maps>

  <!-- views -->
  <view>
    <name>TOC</name>
    <label>Merging HelpSets</label>
    <type>javax.help.TOCView</type>
    <data>LuaTOC.xml</data>
  </view>


</helpset>
