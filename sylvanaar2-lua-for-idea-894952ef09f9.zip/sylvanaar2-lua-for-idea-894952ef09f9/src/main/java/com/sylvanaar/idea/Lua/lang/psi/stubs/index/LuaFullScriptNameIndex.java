///*
// * Copyright 2011 Jon S Akhtar (Sylvanaar)
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// * http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
//package com.sylvanaar.idea.Lua.lang.psi.stubs.index;
//
//import com.intellij.openapi.project.Project;
//import com.intellij.psi.search.GlobalSearchScope;
//import com.intellij.psi.stubs.IntStubIndexExtension;
//import com.intellij.psi.stubs.StubIndexKey;
//import com.sylvanaar.idea.Lua.lang.psi.LuaPsiFile;
//import com.sylvanaar.idea.Lua.lang.psi.search.LuaSourceFilterScope;
//
//import java.util.Collection;
//
//
//public class LuaFullScriptNameIndex extends IntStubIndexExtension<LuaPsiFile> {
//    public static final StubIndexKey<Integer, LuaPsiFile> KEY = StubIndexKey.createIndexKey("lua.script.fqn");
//
//    private static final LuaFullScriptNameIndex ourInstance = new LuaFullScriptNameIndex();
//
//    public static LuaFullScriptNameIndex getInstance() {
//        return ourInstance;
//    }
//
//    public StubIndexKey<Integer, LuaPsiFile> getKey() {
//        return KEY;
//    }
//
//    public Collection<LuaPsiFile> get(Integer integer, Project project, GlobalSearchScope scope) {
//        return super.get(integer, project, new LuaSourceFilterScope(scope, project));
//    }
//}